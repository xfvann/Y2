<?php
$emailku = 'xfvann@gmail.com';
?>